package com.iluwatar.urm.testdomain.family;

import java.util.List;

public class Mother {
  List<Child> childs;
  Child favorite;
}

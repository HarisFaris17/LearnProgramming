package com.iluwatar.urm.testdomain.family;

public class Child {
  Mother mommy;
}

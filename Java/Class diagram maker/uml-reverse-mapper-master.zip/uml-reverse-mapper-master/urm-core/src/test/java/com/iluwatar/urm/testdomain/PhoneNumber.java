package com.iluwatar.urm.testdomain;

public class PhoneNumber {
  private String number;
}

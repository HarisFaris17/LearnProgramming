package com.iluwatar.urm.testdomain.person;

import com.iluwatar.urm.testdomain.Company;
import com.iluwatar.urm.testdomain.PhoneNumber;

import java.util.List;

public class Person {
  private Company company;
  private List<PhoneNumber> contactNumbers;
}

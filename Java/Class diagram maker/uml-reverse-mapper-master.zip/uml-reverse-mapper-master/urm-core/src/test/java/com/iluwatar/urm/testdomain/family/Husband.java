package com.iluwatar.urm.testdomain.family;

public class Husband {
  Wife wife;
}

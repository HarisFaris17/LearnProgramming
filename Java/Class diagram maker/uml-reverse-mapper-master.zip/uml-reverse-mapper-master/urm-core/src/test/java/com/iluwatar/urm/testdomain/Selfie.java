package com.iluwatar.urm.testdomain;

/**
 * Class to test cyclic reference.
 */
public class Selfie {
  private Selfie me;
}

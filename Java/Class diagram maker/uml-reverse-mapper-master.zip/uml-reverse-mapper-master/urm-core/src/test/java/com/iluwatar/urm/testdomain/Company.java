package com.iluwatar.urm.testdomain;

import com.iluwatar.urm.testdomain.person.Person;

import java.util.List;

public class Company {
  private List<Person> employees;
}

package com.iluwatar.urm.testdomain.another;

public class Another {
}

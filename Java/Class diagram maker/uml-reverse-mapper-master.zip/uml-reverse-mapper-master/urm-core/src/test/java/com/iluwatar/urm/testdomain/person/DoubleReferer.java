package com.iluwatar.urm.testdomain.person;

public class DoubleReferer {
  private Manager myBoss;
  private Manager myTeamManager;
}

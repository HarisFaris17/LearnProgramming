package com.iluwatar.urm.testdomain.family;

public class Wife {
  private Husband husband;
}

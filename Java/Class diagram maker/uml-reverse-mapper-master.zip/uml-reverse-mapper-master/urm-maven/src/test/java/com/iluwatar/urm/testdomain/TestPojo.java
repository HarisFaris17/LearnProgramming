package com.iluwatar.urm.testdomain;

public class TestPojo {
}

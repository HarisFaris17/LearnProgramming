package com.milvum.urm.domain;

/**
 * Created by moe on 26.04.16.
 */
public enum DomainClassType {
    CLASS, INTERFACE, ENUM, ANNOTATION;
}

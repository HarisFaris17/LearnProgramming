package com.milvum.urm.domain;

public enum Direction {
    UNI_DIRECTIONAL, BI_DIRECTIONAL
}

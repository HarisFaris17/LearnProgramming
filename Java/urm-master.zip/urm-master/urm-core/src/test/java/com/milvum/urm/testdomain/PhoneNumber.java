package com.milvum.urm.testdomain;

public class PhoneNumber {
    private String number;
}

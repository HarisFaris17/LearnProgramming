package com.milvum.urm.testdomain.family;

public class Child {
    Mother mommy;
}

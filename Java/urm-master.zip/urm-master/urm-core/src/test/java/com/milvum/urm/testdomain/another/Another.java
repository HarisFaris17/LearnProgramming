package com.milvum.urm.testdomain.another;

public class Another {
}

package com.milvum.urm.testdomain.family;

public class Wife {
    private Husband husband;
}

/**
 * this should be ignored by the scanner
 */
package com.milvum.urm.testdomain;

/**
 * this should be ignored by the scanner
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://camel.apache.org/schema/spring", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED) package com.milvum.urm.testdomain.person;

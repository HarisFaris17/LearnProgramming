package com.milvum.urm.testdomain;

import com.milvum.urm.testdomain.person.Person;

import java.util.List;

public class Company {
    private List<Person> employees;
}

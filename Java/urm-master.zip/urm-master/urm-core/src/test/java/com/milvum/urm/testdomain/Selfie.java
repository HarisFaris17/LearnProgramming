package com.milvum.urm.testdomain;

/**
 * Class to test cyclic reference with
 */
public class Selfie {
    private Selfie me;
}

package com.milvum.urm.testdomain.family;

public class Husband {
    Wife wife;
}

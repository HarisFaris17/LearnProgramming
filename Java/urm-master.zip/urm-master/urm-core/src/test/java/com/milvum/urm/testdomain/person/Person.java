package com.milvum.urm.testdomain.person;

import com.milvum.urm.testdomain.Company;
import com.milvum.urm.testdomain.PhoneNumber;

import java.util.List;

public class Person {
    private Company company;
    private List<PhoneNumber> contactNumbers;
}

package com.milvum.urm.testdomain;

public class TestPojo {
}
